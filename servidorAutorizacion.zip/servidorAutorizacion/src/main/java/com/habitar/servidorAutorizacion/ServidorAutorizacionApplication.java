package com.habitar.servidorAutorizacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServidorAutorizacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServidorAutorizacionApplication.class, args);
	}

}
