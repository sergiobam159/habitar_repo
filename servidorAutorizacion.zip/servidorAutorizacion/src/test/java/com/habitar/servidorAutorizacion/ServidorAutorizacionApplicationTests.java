package com.habitar.servidorAutorizacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorAutorizacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
